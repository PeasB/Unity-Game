Hi,
I'm Jeff, your friendly neighbourhood Canadian 
digital artist.  Thank your for downloading
my XBOX 360 XNA Button Pack.

If you use these in your game and it gets published
on the Marketplace or anywhere else... GOOD FOR YOU!
You rock.

Please mention me in the credits for creating
the buttons in your game.  That's all I ask.  Shoot
an email to sinnix@360prophecy if you do and I'll 
be sure to mention it on my blog.

See you on Live,

Jeff
aka Sinnix
360Prophecy.com