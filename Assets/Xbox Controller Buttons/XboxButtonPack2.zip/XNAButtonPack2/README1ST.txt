XNA Button Pack 2
Created by Jeff Jenkins (sinnix@360prophecy.com)
Hosted on 360prophecy.com




Thank you for downloading XNA Button Pack 2!  I hope that you find it useful in making your game/mod better looking!

LICENSE RESTRICTIONS
XNA Button Pack 2 is protected by a Creative Customs license making it free for commercial use so long as...

My name and URL are mentioned in the credit role of your game.

XNA Button Pack MAY NOT BE SOLD on a graphic compilation CD or in any format other than in a Video Game without my express permission.  If you're unsure, email me.

See the Creative Commons link on http://www.360prophecy.com/site/downloads for additional details on licensing.

If your game does eventually make it to XBLA or *gasp* retail release please drop me a line and let me know.  I'm padding my resume and every little bit helps. ;)

Cheers,
Jeff aka Sinnix
Microsoft MVP - XBOX